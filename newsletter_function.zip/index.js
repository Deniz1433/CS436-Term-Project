const nodemailer = require('nodemailer');

exports.sendNewsletter = async (req, res) => {
  // 1) Always set these CORS headers
  res.set('Access-Control-Allow-Origin', '*');
  res.set('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.set('Access-Control-Allow-Headers', 'Content-Type');

  // 2) Immediately respond to OPTIONS (the preflight) and exit
  if (req.method === 'OPTIONS') {
    return res.status(204).send('');
  }

  if (req.method !== 'POST') {
    return res.status(405).send('Method Not Allowed');
  }

  const { email } = req.body;
  if (!email) {
    return res.status(400).send('Missing email');
  }

  const transporter = nodemailer.createTransport({
    host: 'smtp.gmail.com',
    port: 465,
    secure: true,
    auth: {
      user: process.env.GMAIL_USER,
      pass: process.env.GMAIL_PASS,
    },
  });

  try {
    await transporter.sendMail({
      from: `"E-Commerce Website" <${process.env.GMAIL_USER}>`,
      to: email,
      subject: 'Your Newsletter',
      text: 'Thanks for subscribing!',
      html: '<p>Thanks for subscribing!</p>',
    });
    res.status(200).json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).send('Failed to send newsletter');
  }
};
